Manual Test Cases for Coco/R Eclipse Plugin Refactoring Extention
-----------------------------------------------------------------

In General the Manual Tests work as follows:

1. 	Copy and paste the content of test<desired_test>.testdata to test<desired_test>.atg

2. 	Perform test:
	2.1	For RenameTests rename CharSet, Token, Pragma or Production with name <test> to <test>_renamed
	2.2	For ReformatTest toggle a reformat for all productions with default settings.

3. 	Perform a file-diff between test<desired_test>.atg and test<desired_test>.reference. 
	If there are differences, an error has occured.
	
For additional Tests you might require a real-world context environment, therefore please use the package 
javaAtg, as it contains an Coco/R Project for the Java Language (1.4). In case of damage of the atg file 
through the test cases you run, the original content is preserved in java.atg.original. Copy and paste the
content of this file replacing the content in java.atg for a reset, if desired.


Detailed Test Guide:
--------------------

	Test of Rename Character Set Refactoring:
	-----------------------------------------
		0. 	navigate to package testRenameCharSet
		1. 	Copy and paste the content of testRenameCharSet.testdata to testRenameCharSet.atg
		2. 	Select the CharSet "letter" and rename it to "letter_renamed" by triggering Rename
			Refactoring from MainMenu (Refactoring->Rename), ContextMenu (right click->Refactoring->Rename) 
			or by pressing KeyBinding Shift-Alt-R.
		3.	Compare testRenameCharSet.atg and testRenameCharSet.reference. Select both files in
			ProjectExplorer and select "Compare With -> Each Other" in the ContextMenu. 
			If there are no differences, the test has passed.
		
	Test of Rename Token Refactoring:
	---------------------------------
		0. 	navigate to package testRenameToken
		1. 	Copy and paste the content of testRenameToken.testdata to testRenameToken.atg
		2. 	Select the Token "ident" and rename it to "ident_renamed" by triggering Rename
			Refactoring from MainMenu (Refactoring->Rename), ContextMenu (right click->Refactoring->Rename) 
			or by pressing KeyBinding Shift-Alt-R.
		3.	Compare testRenameToken.atg and testRenameToken.reference. Select both files in
			ProjectExplorer and select "Compare With -> Each Other" in the ContextMenu. 
			If there are no differences, the test has passed.

	Test of Rename Pragma Refactoring:
	----------------------------------
		0. 	navigate to package testRenamePragma
		1. 	Copy and paste the content of testRenamePragma.testdata to testRenamePragma.atg
		2. 	Select the Pragma "switch" and rename it to "switch_renamed" by triggering Rename
			Refactoring from MainMenu (Refactoring->Rename), ContextMenu (right click->Refactoring->Rename) 
			or by pressing KeyBinding Shift-Alt-R.
		3.	Compare testRenamePragma.atg and testRenamePragma.reference. Select both files in
			ProjectExplorer and select "Compare With -> Each Other" in the ContextMenu. 
			If there are no differences, the test has passed.

	Test of Rename Production Refactoring:
	--------------------------------------
		0. 	navigate to package testRenameProduction
		1. 	Copy and paste the content of testRenameProduction.testdata to testRenameProduction.atg
		2. 	Select the Production "Statement" and rename it to "Statement_renamed" by triggering Rename
			Refactoring from MainMenu (Refactoring->Rename), ContextMenu (right click->Refactoring->Rename) 
			or by pressing KeyBinding Shift-Alt-R.
		3.	Compare testRenameProduction.atg and testRenameProduction.reference. Select both files in
			ProjectExplorer and select "Compare With -> Each Other" in the ContextMenu. 
			If there are no differences, the test has passed.
			
	Test of Reformat Productions Refactoring:
	-----------------------------------------
		0. 	navigate to package testReformatProductions
		1. 	Copy and paste the content of testReformatProductions.testdata to testReformatProductions.atg
		2. 	Trigger Productions Reformating from MainMenu (Source->Reformat), ContextMenu 
			(right click->Source->Reformat) or by pressing KeyBinding Ctrl-Shift-F.
			Use default settings (reformat all Productions, don't use fixed java tab offset)
		3.	Compare testReformatProductions.atg and testReformatProductions.reference. Select both files in
			ProjectExplorer and select "Compare With -> Each Other" in the ContextMenu. 
			If there are no differences, the test has passed.
		
	